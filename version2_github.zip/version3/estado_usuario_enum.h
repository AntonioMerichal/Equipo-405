#ifndef ESTADO_USUARIO_ENUM_H
#define ESTADO_USUARIO_ENUM_H

enum class estado_usuario_enum
{
    LOGUEADO,
    VISITANTE
};

#endif