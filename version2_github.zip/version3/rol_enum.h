#ifndef ROL_ENUM_H
#define ROL_ENUM_H

enum class rol_enum
{
    ORGANIZADOR,
    DIRECTOR_ACADEMICO,
    USUARIO
};

#endif