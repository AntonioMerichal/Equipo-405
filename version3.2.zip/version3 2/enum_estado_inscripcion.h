#ifndef ESTADO_INSCRIPCION_ENUM_H
#define ESTADO_INSCRIPCION_ENUM_H

enum class estado_inscripcion
{
    PREINSCRITO,
    INSCRITO
};

#endif